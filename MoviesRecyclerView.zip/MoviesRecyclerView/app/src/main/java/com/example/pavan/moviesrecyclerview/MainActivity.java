package com.example.pavan.moviesrecyclerview;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.widget.GridLayout;


public class MainActivity extends AppCompatActivity {
RecyclerView recyclerView;
VersionAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        recyclerView=findViewById(R.id.recyclerview);
        int[] images={R.drawable.vijay,R.drawable.band,R.drawable.download,R.drawable.gopi,R.drawable.jay,
                R.drawable.key,R.drawable.nani,R.drawable.ntr,R.drawable.ragada,R.drawable.ravi,R.drawable.saksyam};


        String[] movies={"geethagovindam","bandbabu","saksyam","jay lava kusa","key","krishna","arvind","ragada","nelaticket","saksyam"};
        adapter=new VersionAdapter(this,images,movies);
        recyclerView.setLayoutManager(new GridLayoutManager(this,2));
recyclerView.setAdapter(adapter);

    }
}
