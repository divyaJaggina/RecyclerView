package com.example.pavan.moviesrecyclerview;

import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Adapter;
import android.support.v7.widget.RecyclerView;
import android.widget.ImageView;
import android.widget.TextView;

public class VersionAdapter extends RecyclerView.Adapter<VersionAdapter.VersionHolder> {
   MainActivity mainActivity;
   int[] img1;
   String[] names;

    public VersionAdapter(MainActivity mainActivity1, int[] images, String[] movies) {
        mainActivity=mainActivity1;
        img1=images;
        names=movies;
    }

    @NonNull
    @Override
    public VersionAdapter.VersionHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
      View view=LayoutInflater.from(mainActivity).inflate(R.layout.row,viewGroup,false);
      VersionHolder versionHolder=new VersionHolder(view);

        return versionHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull VersionAdapter.VersionHolder versionHolder, int i) {
      versionHolder.img.setImageResource(img1[i]);
      versionHolder.tv.setText(names[i]);
    }

    @Override
    public int getItemCount() {
        return names.length;
    }

    public class VersionHolder extends RecyclerView.ViewHolder {
        ImageView img;
        TextView tv;
        public VersionHolder(@NonNull View itemView) {
            super(itemView);
            img=itemView.findViewById(R.id.img);
            tv=itemView.findViewById(R.id.tv);
        }
    }
}
